import { ProjectConfig } from '@/components/ProjectConfig/ProjectConfig'

export default function ProjectConfigPage() {
  return <ProjectConfig />
}