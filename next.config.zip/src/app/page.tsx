import { Dashboard } from '@/components/Dashboard/Dashboard'

export default function Home() {
  return <Dashboard />
}