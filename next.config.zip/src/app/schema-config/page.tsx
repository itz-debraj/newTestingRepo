import { SchemaConfig } from '@/components/SchemaConfig/SchemaConfig'

export default function SchemaConfigPage() {
  return <SchemaConfig />
}